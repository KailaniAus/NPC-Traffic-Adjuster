---------------------------------------
----- CREATED BY NOVACANE#0001 -----
----- NOVAMODIFICATIONS@GMAIL.COM -----
---------------------------------------

client_script "config.lua"